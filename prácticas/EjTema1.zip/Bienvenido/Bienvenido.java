/** Muestra en consola un texto de bienvenida a IP
 *  @author los profesores de IP  */
public class Bienvenido {
	public static void main(String[ ] args) {
		/* Imprimimos las cadenas "Bienvenido a" e
		"Introducción a la Programación" en dos líneas */
		System.out.println("Bienvenido a");
		System.out.print("Introducción a la Programación");
	}
}
