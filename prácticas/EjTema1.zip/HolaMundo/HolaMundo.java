/** Muestra por pantalla el mensaje "Hola, Mundo"
 *  @author los profesores de IP  */ 
public class HolaMundo {

	public static void main(String[ ] args) {
		//Imprimimos el mensaje Hola, Mundo
		System.out.print("Hola, Mundo");
	}

}
