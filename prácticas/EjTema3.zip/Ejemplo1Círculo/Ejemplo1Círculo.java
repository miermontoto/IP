import java.util.Scanner;

/** Ejemplo 1 de uso de la clase Círculo
 *  @author los profesores de IP  */
public class Ejemplo1Círculo {

	public static void main(String[ ] args) {
		//Objeto de la clase Círculo
		Círculo c = new Círculo();
		//Objeto Scanner asociado con el teclado
		Scanner teclado= new Scanner(System.in);
		//Leemos el radio
	    System.out.print("Introduce el radio: ");
	    c.setRadio(teclado.nextDouble());
		//Mostramos el área en la pantalla
		System.out.printf("El área es %f\n",c.calculaÁrea());
	}
}
